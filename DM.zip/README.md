# Question_bot_v1
DIscord Question_bot_project

디스코드를 기반으로 제작되었으며 python 3.7.5버전을 사용하여 제작된 봇입니다

## Setting
파이썬을 **3.9**버전 이하로 다운하여 셋팅해주세요 [[python download]](https://www.python.org/)

파이썬을 설치까지 완료되었다면 module_setup.bat을 실행시켜주세요!

## Bot
봇 생성 디스코드 개발자 포털 : [DISCORD DEVELOPER PORTAL](https://discord.com/developers/applications)

봇을 생성 후 봇 토큰 확인 페이지 아래에 있는 PRESENCE INTENT, SERVER MEMBERS INTENT 이 2개를 꼭 켜주세요!

## Start Bot
위 사항들이 모두 완료되었다면 Start_bot.bat파일을 실행시켜주세요! 실행도중 에러가 있다면 MOS_우기 카테고리에있는 질문방에 올려주세요!

## Developer's Word
해당 봇 및 다른 봇들은 MOS_우기 카테고리에있는 아이디어채널에 아이디어를 올려주시면 업데이트 또는 새로 개발이 진행됩니다!

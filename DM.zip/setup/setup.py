from os import system

system('pip install -r setup/requirements.txt')
system('pause')